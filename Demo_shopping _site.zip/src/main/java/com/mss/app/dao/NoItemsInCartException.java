package com.mss.app.dao;

public class NoItemsInCartException extends Exception {



public NoItemsInCartException(String message)
{
super(message);
}



}