package com.mss.app.entity;

public class TaxCalcUtil {

	private String state="new jersey";
   	private double amount=100;
   	private double tax;
   	private double totalAmount;
   	
  	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	
   
    	
   	
	
}

	

	
